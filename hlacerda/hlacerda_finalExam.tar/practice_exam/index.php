<?php
 	include "controllers/register.php";
	
		$controller = new Register();
		$controller->get($_GET);
		
	
			
?>