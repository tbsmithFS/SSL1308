<pre>
<?php

include 'connection.php';



/*
if (empty($_POST["good"])){
	$good = false;
} else {
$good = true;
}


if (empty($_POST["bad"])){
	$bad = false;
} else{
$bad = true;
}

if($bad == true){
	$post = 2;
}else{
	$post = 1;
}

*/
/*
ß
$translate = $_POST['translate'];
*/

$search = $_POST["search"];



echo $search;

$locationAPI = "http://www.biomedcentral.com/search/results?terms=".$search."&format=json";

/* $locationAPI = "http://glosbe.com/gapi/translate?from=eng&dest=".$translate."&format=json&phrase=".$text."&pretty=true"; */
$results = file_get_contents($locationAPI);


$deCode = json_decode($results, true);

echo "</br>" . $locationAPI . "</br>";
/* echo "</br>".$deCode['entries']."</br>"; */

/* var_dump($deCode['entries']); */

$text = $deCode['entries'][1]['bibliograhyTitle'];

$author = $deCode['entries'][1]['authorNames'];


$Connect = new DBConnector();
$Connect->addSearch($text, $author);

/* $entrycount = count($deCode['entries']); */

foreach($deCode['entries'] as $entry => $value){
	
	$newAuthor = $value['authorNames'];
	
	$newType = $value["type"];
	
	$newDef = $value['bibliograhyTitle'];
	

	
  echo "</br>".$newAuthor."</br>".$newType."</br>".$newDef."</br";
	
	
}




/* var_dump($entries['bibliograhyTitle']); */


	
?>
</pre>