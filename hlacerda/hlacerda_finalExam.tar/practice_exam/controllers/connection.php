<?php

	class DBConnector{
		
		private $db;
		
		function __construct(){
			$host = '127.0.0.1';
			$user = 'root';
			$pass = 'root';
			$port = '8889';
			$dbname = 'storeSearch';
			$this->db = new PDO("mysql:host=$host;
								 port=$port;
								 dbname=$dbname",
								 $user, $pass);
		
		}
	
	
	function addSearch($text='', $author=''){
		$stmnt = $this->db->prepare("insert into finds(text, author) values (:text, :author)");
		$stmnt->execute(array(
			':text'=> $text,
			':author'=> $author,
			));
	}
}


?>