<html>
	<body>
		<form action="controllers/welcome.php" enctype="multipart/form-data" method="post">
			<input type="text" name="search" value="text" /><br>
			<button type="submit" value="search">Submit</button>
		</form>
	</body>
</html>