<html>
	<body>
		<form action="controllers/welcome.php" enctype="multipart/form-data" method="post">
		Username:<input type="text" name="username"><br/>
		Eamil:<input type="email" name="email"><br/>
		Password:<input type="password" name="password"></br>
<input type="submit" name="Submit"> 
		</form>
	</body>
</html>