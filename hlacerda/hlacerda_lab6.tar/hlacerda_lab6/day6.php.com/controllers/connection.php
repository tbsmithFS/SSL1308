<?php

	class DBConnector{
		
		private $db;
		
		function __construct(){
			$host = '127.0.0.1';
			$user = 'root';
			$pass = 'root';
			$port = '8889';
			$dbname = 'fakeUsers';
			$this->db = new PDO("mysql:host=$host;
								 port=$port;
								 dbname=$dbname",
								 $user, $pass);
		
		}

	
	function addUser($username='', $email='', $password=''){
	$stmnt = $this->db->prepare("insert into usrs(username, email, password) values (:username, :email, :password)");
	$stmnt->execute(array(
		':username'=> $username,
		':email'=> $firstname,
		':passowrd'=> $password
		));
	}
}

?>