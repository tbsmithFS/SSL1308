<?php

/*
function build_house($width, $length){
	
}

function build_nieghtborhood($num_houses){
	for ($i=0; $i<$numb_houses; $i++){
		build_house(500, 800);
	}
}

build_neightborhood(25);
*/


$example = {"dog, cat, pet, fish"};

var_dump(json_encode($example));

?>