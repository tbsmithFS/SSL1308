#!/usr/bin/python

class Person:
	def __init__(self):
		self.species = "homosapien"
		self.age = 0

p = Person()
print p.speciesf

class otherPerson:
	def __init__(self):
		self.species = "undefined"
		self.age = 0

o = otherPerson()
print o.species

class thatGuy:
	def __init__(self):
		sefl.species = "ancient man"
		self.age = 100

g = thatGuy()
print g.age

