<div id=body>
	My body text is $body_text.
</div>