
<html>
	<body>
		<form action="receiver.php" enctype="multipart/form-data" method="post">
		Username:<input type="text" name="username"><br/>
		password:<input type="password" name="password"><br/>
<input type="submit" name="Submit"> 
		</form>
	</body>
</html>
