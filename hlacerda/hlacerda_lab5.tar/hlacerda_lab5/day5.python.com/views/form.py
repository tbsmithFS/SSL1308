<html>
	<body>
		<form action="welcome.py" enctype="multipart/form-data" method="post">
		Name:<input type="text" name="name"><br/>
		Age:<input type="text" name="age"><br/>
		<input type="radio" name="sex" value="male">Male<br/>
<input type="radio" name="sex" value="female">Female
		<input type="checkbox" name="vehicle" value="Bike">I have a bike<br/>
<input type="checkbox" name="vehicle" value="Car">I have a car</br>

<input type="submit" name="Submit"> 
		</form>
	</body>
</html>

