<div id=body>
	<h2> Blog Title One </h2>
        	<p> Here is the first article.</p>
	
</div>