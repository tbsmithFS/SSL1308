<nav>
  <a href="#">Home</a>
  <a href="#">About Us</a>
  <a href="#">Contact</a>
  <a href="#">Registration</a>
</nav>