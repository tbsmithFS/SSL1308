<div id=wrapper>	
	<div id=wrapper2>
	<div id=header>
		<h1 id="logo">{hugo:Lacerda}</h1>
			<nav>
				<ul>
					<li><a href="#">Image Gallery</a></li>
					<li><a href="#">User Registration Form</a></li>
					<li><a href="#">Blog</a></li>
					<li><a href="#">Autocompleter</a></li>
					<li><a href="#">Accordion</a></li>
				</ul>				
			</nav>
	</div>
	<div id=body>
		<ul>
			<li>Thing 1</li>
			<li>Thing 2</li>
			<li>Thing 3</li>
			<li>Thing 4</li>
			<li>Thing 5</li>
		</ul>
		<div id=container>
		<span>Body is <?php echo $data{'main_body_text'} ?>
		Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum dignissim semper mauris, in sagittis augue fringilla eu. Sed mollis lacinia erat, non facilisis sapien ornare quis. Phasellus quis venenatis quam, ac porttitor nisi. Vivamus ullamcorper leo id enim tempor, vel vehicula urna bibendum. Aenean bibendum felis id ligula molestie, non consequat nulla fringilla. Integer arcu neque, pulvinar eu turpis ut, laoreet porta est. Cras luctus nulla ut fringilla condimentum. Etiam et adipiscing dui. Donec ultricies leo nibh, non cursus sem consequat et. Duis eros purus, porta laoreet laoreet quis, pellentesque non est. Duis sit amet purus accumsan, mattis urna et, ultricies enim. Phasellus fermentum nunc est, quis iaculis mauris cursus in.</span>
		</div>
	</div>
	<div id=footer>
		<span>Copyright Hugo Lacerda 2013</span>
	</div>
	</div>
</div>