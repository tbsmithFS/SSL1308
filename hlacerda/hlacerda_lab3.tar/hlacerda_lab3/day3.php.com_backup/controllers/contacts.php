<?php

/*
	this is our main interface for the user
	for handling the displaying of static pages
*/


require_once 'models/view.php';

class Contacts {
	function get($pairs, $data = ''){
		if(empty($pairs['action'])){
			$action = 'contacts';
		}else{
			$action = $pairs['action'];
		}
		
		$view_model = new View();
		$view_model->getView("header");
	
	
	$data = array(
    		'username' => "Hugo",
    		'controller' => "contacts");
    		
    $view_model->getView("header", $data);
    $view_model->getView('sidebar', $data);
    if ($action == 'contacts'){
    		$view_model->getView("contacts", $data);
		} else if ($action == 'about'){
    		$view_model->getView('about', $data);
		} else {
    		$view_model->getView('home', $data);
		}
		$view_model->getView('footer', $data);
		
	}
}

?>