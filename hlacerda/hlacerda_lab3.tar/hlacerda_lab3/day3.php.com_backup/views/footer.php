	<div id=footer>
		<!--  <span>footer is working</span> -->
		<span>Copyright Hugo Lacerda 2013</span>
	</div>
	</div>
</div>