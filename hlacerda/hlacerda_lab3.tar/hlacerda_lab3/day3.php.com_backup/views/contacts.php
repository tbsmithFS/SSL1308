
<div id=wrapper>	
	<div id=wrapper2>
	<div id=header>
		<h1 id="logo">{hugo:Lacerda}</h1>
			<nav>
				<ul>
					<li><a href="#">Image Gallery</a></li>
					<li><a href="#">User Registration Form</a></li>
					<li><a href="#">Blog</a></li>
					<li><a href="#">Autocompleter</a></li>
					<li><a href="#">Accordion</a></li>
				</ul>				
			</nav>
	</div>
	<div id=body>
		<div id=container>
		<span>Body is this is the contacts page</span>
		</div>
	</div>
	