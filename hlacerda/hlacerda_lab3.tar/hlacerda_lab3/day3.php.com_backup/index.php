<?php
	/* include("settings/db.php"); */
	if (empty($_GET["controller"])){
		$con = "home";
	} else {
		$con = $_GET["controller"];	
	}
	
	if ($con == 'home') {
		include "controllers/home.php";
		$controller = new Home();
		$controller->get($_GET);
	} else if ($con == 'contacts'){
		include "controllers/contacts.php";
		$controller = new Contacts();
		$controller->get($_GET);
	}else if($con == 'about') {
		include "controllers/about.php";
		$controller = new About();
		$controller->get($_GET);
	}
	
	
?>