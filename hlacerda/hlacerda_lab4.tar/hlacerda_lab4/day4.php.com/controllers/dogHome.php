<?php

require "Cat.php";

$myCat = newCat();

$myCat->name = "Ginger";

$myCat->age = 6;

$myCat->setCatID(22);


?>