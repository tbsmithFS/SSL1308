<div id="footer">
$copyright_info
</div>

</body>
</html>
