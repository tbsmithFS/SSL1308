<!DOCTYPE html>
<html lang="en">
<head>
	<title>$site_title</title>
	<link href="css/main.css" />
</head>

<body>
	<div id="header">
		$logo_title
	</div>
