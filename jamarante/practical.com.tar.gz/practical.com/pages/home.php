<?php

class Home {

    function __construct() {
        $this->init();
    }
    
    function init() {
        include_once('models/view.php');
        
        $view = new View();
        $view->printHeader();
        $view->getView('header');
        $view->getView('searchForm');
        
        include_once("database/connection.php");
        $query = mysql_query("SELECT * FROM Search;") or die(mysql_error());
        while ($search = mysql_fetch_array($query)) {
            echo "</br>Author: ".$search['author']."</br>";
            echo "Url: ".$search['url']."</br>";
            echo "Citation: ".$search['citation']."</br>";
        }
        
        $view->getView('footer');
    }
    
}

?>