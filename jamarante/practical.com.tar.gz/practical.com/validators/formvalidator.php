<?php

class FormValidator {

function validate($array) {
//	$fullName = $array["username"];

	/*if (empty($fullName) || empty($email) || empty($password) || empty($confirmPassword)) {
		return "Please fill all the fields correctly.";
	}*/

	return "valid";
}

}

?>
