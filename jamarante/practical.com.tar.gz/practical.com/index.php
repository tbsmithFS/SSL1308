<?php

include("helpers/pathcontroller.php");

$url = new PathController("/review.com");
$segment = $url->getSegment(2);

if ($segment == '' || $segment == 'home') {
    include_once('pages/home.php');
    $home = new Home();
} else {
    echo "Error 404";
}

?>