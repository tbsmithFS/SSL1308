<form id="search_form" action="formcontroller.php" name="simple_form" method="post">
    <label>Query</label>
    <input type="text" name="search_query" />
    <input type="submit" value="Search & Add" />
</form>