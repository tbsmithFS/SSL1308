<!DOCTYPE html>
<html lang="en">
    <head>
        <title>The Practical</title>
        <meta charset="utf-8">
        <!--<link href="css/main.css" rel="stylesheet"/>-->
    </head>
    
    <body>
    
        <header>
            <h1><a href="home">SSL Final</a></h1>
        </header>