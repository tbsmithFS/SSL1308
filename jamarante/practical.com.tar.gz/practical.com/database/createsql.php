<?php

class CreateSQL {

    function create($author, $url, $citation) {
        include("database/connection.php");
    
        mysql_query("INSERT INTO Search (author, url, citation)
                     VALUES ('$author', '$url', '$citation');");
    }
    
}

?>