<?php
    if (!empty($_POST)) {
        $query = $_POST['search_query'];
        
        if (strlen($query) > 0) {
            $url = "http://www.biomedcentral.com/search/results?terms=".$query."&format=json";
            $response = json_decode(file_get_contents($url));        
            $entry = $response->entries[0];
            
            $author = $entry->authorNames;
            $url = $entry->type;
            $citation = $entry->longCitation;
            
            /*if (strlen($title) || strlen($text) || strlen($articleUrl) || strlen($names)) {
                // not valid.
            } else {*/
                include_once("database/createsql.php");
                $database = new CreateSQL();
                $database->create($author, $url, $citation);
//            }
        }
        
        header("location: index.php");   
    }
?>