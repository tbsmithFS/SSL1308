<form id="query_form" action="" name="simple_form" method="post">
    <label>DuckDuckGo</label>
    <input type="text" name="query" />
    <input class="button" type="submit" value="Submit" />
</form>