<form id="user_form" action="" name="simple_form" method="post">
    <h2>Sign Up</h2>
    <label>Username</label>
    <input type="text" name="username" /><br>
    <label>Email</label>
    <input type="text" name="email"/><br>
    <label>Password</label>
    <input type="password" name="password" /><br>
    <label>Confirm Password</label>
    <input type="password" name="confirm_password" /><br>
    <input class="button" type="submit" value="Submit" />
</form>
