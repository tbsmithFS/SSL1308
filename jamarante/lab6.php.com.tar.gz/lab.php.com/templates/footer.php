<footer>
    <p>Copyright Info &copy;</p>
</footer>

</body>
</html>