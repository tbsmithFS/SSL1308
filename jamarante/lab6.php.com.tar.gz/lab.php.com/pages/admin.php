<?php

class Admin {

    function __construct() {
        $this->init();
    }
    
    function init() {
        include_once('models/view.php');
        include_once('database/connection.php');
        
        $view = new View();
        $view->printHeader();
        $view->getView('header');
        
        $query = "SELECT * FROM People;";
        $result = mysql_query($query);
        
        echo "<div class='datagrid'>";
        while($person = mysql_fetch_array($result)) {
            $user = $person["username"];
            $email = $person["email"];
            
            echo "<div class='row'>";
            echo "<p class='user'>" . $user . "</p>";
            echo "<p class='email'>" . $email . "</p>";
            echo "</div>";
        }
        echo "</div>";
        
        if (!empty($_POST)) {  
            $query = $_POST["query"];
            if (query != "") {
                $content = file_get_contents("http://api.duckduckgo.com/?q=Burger&format=json&pretty=1");
                $content = json_decode($content);
                $result = $content->RelatedTopics[0]->Result;
                echo "<p id='reply'>$result</p>";
            } 
        }
        
        $view->getView('queryform');
        $view->getView('footer');
    }
    
}

?>