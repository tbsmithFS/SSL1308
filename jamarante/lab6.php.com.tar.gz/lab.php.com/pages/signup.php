<?php

class SignUp {

    function __construct() {
        $this->init();
    }
    
    function init() {
        include_once('models/view.php');
        
        $view = new View();
        $view->printHeader();
        $view->getView('header');
        
        if (!empty($_POST)) {
            include_once('validators/formvalidator.php');
            
            $formFields = array(
                'username' => $_POST['username'],
                'email' => $_POST['email'],
                'password' => $_POST['password'],
                'confirm_password' => $_POST['confirm_password']
            );
            
            $validator = new FormValidator();
            $message = $validator->validate($formFields);
            
            if ($message == "valid") {
                include_once('database/createsql.php');
                
                $user = $formFields['username'];
                $email = $formFields['email'];
                $pass = $formFields['password'];
                
                $create = new CreateSQL();
                $create->create($user, $email, $pass);
                
                echo "<h2 class='cta'>" . $formFields['username'] . " has been added.</h2>";
            } else {
                echo "<h2 class='cta'>" . $message . "</h2>";
            }
        } else {
            echo "<h2 class='cta'>Sign up to PHP!</h2>";
        }
        
        $view->getView('signupform');
        $view->getView('footer');
    }
    
}

?>