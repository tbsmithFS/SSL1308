<?php

class View {

function __construct () {
	echo "constructor";
}

}

?>
