<?php

//include("scripts/view.php");
//$view = new View();

//include("scripts/dbconnector.php");
//$db = new DBConnector();

include "includes/connection.php";

$query = "SELECT * FROM People";

$result = mysql_query($query);

while($person = mysql_fetch_array($result)) {
	echo "<h3>" . $person['Name'] . "</h3>";
    echo "<p>" . $person['Description'] . "</p>";
    echo "<a href=\"modify.php?id=" . $person['ID'] . "\">Modify User</a>";
    echo "<span> </span>";
    echo "<a href=\"delete.php?id=" . $person['ID'] . "\">Delete User</a>";
}

?>

<h1>Create A User</h1>
<form action="create.php" method="post">
<input type="text" name="inputName" value="" />
<input type="text" name="inputDescription" value="" />
<br>
<input type="submit" name="submit" />
</form>

