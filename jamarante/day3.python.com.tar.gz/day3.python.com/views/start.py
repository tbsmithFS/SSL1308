<div id="message">
$start
</div>