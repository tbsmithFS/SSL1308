<div id="message">
$name
</div>