<div id="body">
$main_body_text
</div>
