<div id="message">
$empty
</div>
