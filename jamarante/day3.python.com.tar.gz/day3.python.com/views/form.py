<form id="user_form" action="" name="simple_form" method="post">
<label>Full Name</label>
<input type="text" name="full_name" /><br>
<label>Email</label>
<input type="text" name="email"/><br>
<label>Password</label>
<input type="password" name="password" /><br>
<label>Confirm Password</label>
<input type="password" name="confirm_password" /><br>
<input class="button" type="submit" value="Submit" />
</form>
        
