<div id="message">
$pass_match
</div>