<div id="message">
$pass_length
</div>