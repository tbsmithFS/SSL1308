<div id="message">
$email
</div>