<form id="user_form" action="" name="simple_form" method="post">
    <h2>Sign In</h2>
    <label>Username</label>
    <input type="text" name="user_name" /><br>
    <label>Password</label>
    <input type="password" name="password" /><br>
    <input class="button" type="submit" value="Submit" />
</form>