<!DOCTYPE html>
<html lang="en">
    <head>
        <title>PHP Site</title>
        <meta charset="utf-8">
<!--        <link href="css/main.css" rel="stylesheet"/>-->
        <link ref="shortcut icon" href="/favicon.ico" type="image/x-icon"/>
    </head>
    
    <body>
    
        <header>
            <h1><a href="home">PHP</a></h1>
            
            <ul>
                <li><a href="signup">Sign Up</a></li>
                <li><a class="right_nav_anchor" href="admin">Admin</a></li>
            </ul>
        </header>