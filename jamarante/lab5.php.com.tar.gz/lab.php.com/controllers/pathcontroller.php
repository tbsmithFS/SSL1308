<?php

class PathController {

    private $site_path;
    private $segments;

    function __construct($site_path) {
        $this->site_path = $this->removeSlash($site_path);
        $this->partition();
    }
    
    private function removeSlash($string) {
        if ($string[strlen($string) - 1] == '/') {  
            $string = rtrim($string, '/');
        }
        
        return $string;
    }
    
    private function partition() {
        $segments = str_replace($this->site_path, '', $_SERVER['REQUEST_URI']);
        $segments = explode('/', $segments);
        
        $this->segments = $segments;
    }

    function getPath() {
        return $this->site_path;
    }
    
    function getSegment($segment) {
        if (isset($this->segments[$segment])) {
            return $this->segments[$segment];
        } else {
            return false;
        }
    }
}

?>
