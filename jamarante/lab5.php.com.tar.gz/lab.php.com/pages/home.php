<?php

class Home {

    function __construct() {
        $this->init();
    }
    
    function init() {
        include_once('models/view.php');
        
        $view = new View();
        $view->printHeader();
        $view->getView('header');
        
        if ($_SESSION['loggedin']) {
            echo "<h2 class='cta'>" . $_SESSION['username'] . " has logged in.</h2>";
        }
        else if (empty($_POST)) {
            echo "<h2 class='cta'>Sign in to your PHP account.</h2>";
        } else {
            include_once("database/login.php");
        }
        
        $view->getView('signinform');
        $view->getView('footer');
    }
    
}

?>