<?php

session_start();

include("controllers/pathcontroller.php");

$url = new PathController("/lab.php.com");
$segment = $url->getSegment(1);

if ($segment == '' || $segment == 'home') {
    include_once('pages/home.php');
    $home = new Home();
} 
else if ($segment == 'signup') {
    include_once('pages/signup.php');
    $signup = new SignUp();
} 
else if ($segment == 'admin') {
    include_once('pages/admin.php');
    $admin = new Admin();
} else {
    echo "Error 404";
}

?>