<div id="footer">
	<?php echo $data{"copyright_info"} ?>
</div>

</body>
</html>
