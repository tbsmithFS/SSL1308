<!DOCTYPE html>

<html lang="en">
<head>
	<title><?php echo $data{"site_title"} ?></title>
	<link href="css/main.css" rel="stylesheet" />
</head>

<div id="header">
	<?php echo $data{"logo_title"} ?>
</div>
