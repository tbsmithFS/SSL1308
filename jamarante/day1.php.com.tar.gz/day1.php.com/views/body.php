<div id="body">
	<?php echo $data{"main_body_text"} ?>
</div>
