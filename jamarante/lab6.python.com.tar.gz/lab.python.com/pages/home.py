class Home:
    def __init__(self):
        from models.view import View
        view = View()
        view.print_header()
        view.get_view("header")
        print "<h2 class='cta'>Welcome to Python!</h2>"
        view.get_view("footer") 