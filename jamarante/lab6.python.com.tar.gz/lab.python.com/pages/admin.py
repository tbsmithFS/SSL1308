class Admin:
    def __init__(self):
        from models.view import View
        from database.connect import Connect
        
        view = View()
        view.print_header()
        view.get_view("header")
        
        connector = Connect()
        
        view.get_view("footer")