class SignUp:
    def __init__(self):
        from models.view import View
        view = View()
        view.print_header()
        view.get_view("header")
        view.get_view("signupform");
        view.get_view("footer")
        
    def validate(self):
        import cgi, cgitb
        import re
        form = cgi.FieldStorage()
        if not (form.has_key("username")):
            print "<h2 class='cta'>Please fill all the fields correctly.</h2>"
        elif not (form.has_key("email")):
            print "<h2 class='cta'>Please fill all the fields correctly.</h2>"
        if (form.has_key("email")):
             if (re.search("^\w+@(\w+\.)+\w+$", form["email"].value) == None):
                print "<h2 class='cta'>Invalid Email.</h2>"
                return
        if (form.has_key("password")):
            if (form.has_key("confirm_password")):
                if (len(form["password"].value) < 8):
                    print "<h2 class='cta'>Password must be at least 8 characters long.</h2>"
                elif (form["password"].value != form["confirm_password"].value):
                    print "<h2 class='cta'>Passwords do not match.</h2>"
