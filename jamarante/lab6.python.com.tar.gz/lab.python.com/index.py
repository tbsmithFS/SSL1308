#!/usr/bin/python

import os
from controllers.path import Path

url = os.environ['REQUEST_URI']

path = Path()
page = path.getSegment(url)

if (page == '' or page == 'home' or page == 'index.py'):
    from pages.home import Home
    home = Home()
elif (page == 'signup'):
    from pages.signup import SignUp
    signup = SignUp()
    signup.validate()
elif (page == 'admin'):
    from pages.admin import Admin
    admin = Admin()
else:
    print "Error 404"