class Connect():
    def __init__(self):
        import MySQLdb
        import json
        
        db = MySQLdb.connect(
                            host = 'localhost',
                            user = 'root',
                            passwd = 'root',
                            db = 'mysql_tut'
                            )
        
        cur = db.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT * FROM People")
        rows = cur.fetchall()
        
        print "<div class='datagrid'>"
        for row in rows:
            print "<div class='row'>"
            print "<p class='user'>" + row["username"] + "</p>"
            print "<p class='email'>" + row["email"] + "</p>"
            print "</div>"
        print "</div>"
        
        print "<p id='reply'>" + json.dumps(rows) + "</p>";