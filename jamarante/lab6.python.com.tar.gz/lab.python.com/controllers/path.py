class Path:
    def __init__(self):
        self.base_path = ""
        
    def getSegment(self, segment = []):
        segment = segment.split('/')
        return segment[-1]