<?php 

	class MyName {
		public $name;
		public $lastName;
		
		public function setName($givenValue, $givenValueTwo){
			$this->name = $givenValue;
			$this->lastName = $givenValueTwo;
		}
		public function getName(){
			return $this->name;
		}
	}
?>