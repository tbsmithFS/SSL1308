<?php
	
	include("settings/db.php");
	include("models/view.php");
	// include("models/SetUrl.php");
	include("test.php");

	$view = new View();
	
	$view -> printHeader();

	$data = array (
		'site_title' => "My PHP website title", 
		'logo_title' => "My PHP logo", 
		'main_body_text' => "Main body text for PHP site", 
		'copyright_info' => "Full Sail University 2013",
	);

	$view->getView("header", $data);
	$view->getView("body", $data);
	$view->getView("footer", $data);
	
	
	// this can all be deleted
	$test = new MyName();
	$test->setName("Hugo", "Ybarra");
	echo $test->getName();
	var_dump($test->getName());
	
	
