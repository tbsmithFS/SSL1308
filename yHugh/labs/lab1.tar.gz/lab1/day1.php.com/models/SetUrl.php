<?php
	$myUrl = "http://user.name:password@someWebsite/Path1/Path2/Path3?arg=valueAnchor";
	
	print_r(parse_url($url));
	echo parse_url($url, PHP_URL_PATH);
?>