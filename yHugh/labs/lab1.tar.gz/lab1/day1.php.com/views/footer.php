<footer>
	<ul class="nav nav-tabs">
		<li class="active">
			<a href="#">Home</a>
		</li>
		<li>
			<a href="#">Some Link</a>
		</li>
		<li>
			<a href="#">Some Link</a>
		</li>
	</ul>
</footer>