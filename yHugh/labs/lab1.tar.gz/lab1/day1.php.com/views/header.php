<head>
	<link rel="stylesheet" href="../css/bootstrap.css" type="text/css" >
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>
	<title>Skully</title>
</head>
<header>
	<div class="navbar">
	  <a class="navbar-brand" href="#">Title</a>
	  <ul class="nav navbar-nav">
	    <li class="active"><a href="#">Home</a></li>
	    <li><a href="#">Link</a></li>
	    <li><a href="#">Link</a></li>
	  </ul>
	</div>
</header>