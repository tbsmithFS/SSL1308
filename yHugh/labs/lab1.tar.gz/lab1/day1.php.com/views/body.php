<div class=" span8 hero-unit  col-lg-offset-4" id="myHero">
	<h1>Hey Look right here!</h1>
	<p>
		If I had something to say to you I would probably
		put it right here! That being said,</br>
		if you're reading this
		that means that i had something to say ^_^
	</p>
	
	<p>
		<a class="btn btn-primary btn-large"> Learn more </a>
	</p>
</div>

