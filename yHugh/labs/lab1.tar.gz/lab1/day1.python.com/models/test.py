#!/usr/bin/python
class SomeClass:
    def setName(self, inOne, inTwo):
        self.name = inOne
        self.last = inTwo
    
    def getName(self):
        return self.name + " " + self.last
    
    