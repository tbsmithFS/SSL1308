<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../css/bootstrap.css" type="text/css" >
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"/>
    <title>Skully</title>
</head>

<head>
    <ul class="nav nav-tabs">
        <li class="active">
            <a href="#">Home</a>
        </li>
        <li>
            <a href="#">Some Link</a>
        </li>
        <li>
            <a href="#">Some Link</a>
        </li>
    </ul>
</head>