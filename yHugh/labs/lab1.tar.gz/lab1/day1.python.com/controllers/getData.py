#!/usr/bin/python

print "ran"