#!/usr/bin/python
from models.view import View


class Home():

    view_model = View()
    view_model.print_header()

    data = {"site_title": "MyPython Web Site",
            "logo_title": "My WebSite Logo",
            "body_text": "This is my main body text",
            "copyright_info": "fullsail university 2013"}

    view_model.get_view("header", data)
    view_model.get_view("body", data)
    view_model.get_view("footer", data)