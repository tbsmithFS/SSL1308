#!/usr/bin/python
__author__ = 'Hugh'

import cgi
import cgitb
import re
cgitb.enable()  # for better debugging we are enabling the cgitb

print "Content-type: text/html\n\n"

#==== RADIO VALIDATION
value1 = "unchecked"
value2 = "unchecked"
radioCheck = False
testForm = cgi.FieldStorage()

if testForm.getvalue("formVal"):
    selectedValue = testForm.getvalue("formVal")
else:
    selectedValue = "notChecked"

if selectedValue == "valOne" or selectedValue == "valTwo":
    if selectedValue == "valOne":
        value1 = "checked"
        radioCheck = True
        # print "value 1 checked"
    if selectedValue == "valTwo":
        value2 = "checked"
        radioCheck = True
        # print "value 2 Checked "

else:
    # print "not Checked"
    radioCheck = False

#==== CHECKBOX VALIDATION
iExist = False
if testForm.getvalue("form_check"):
    iExist = True
    # print "I do Exist", "/n"
else:
    iExist = False
    # print "you claim to not exist"


# ===== checking required input fields
eData = {"name": "", "email": "","phone": ""}
if "first_name" not in testForm or "form_email" not in testForm or "form_phone" not in testForm:
    formInput = False
    formIsValid = False
else:
    formInput = True
# validating form
if formInput:
    #==== NAME VALIDATION
    if testForm["first_name"].value:
        fName = testForm["first_name"].value
        fNameCheck = False


    regexName = re.search("^[a-zA-Z]+", fName)
    if regexName:
        # print "match"
        fNameCheck = True
        eData["name"] = True
    else:
        # print "no Match"
        fNameCheck = False
        eData["name"] = True

    #===== EMAIL VALIDATION
    fEmail = testForm["form_email"].value
    fEmailCheck = False

    regexEmail = re.search("^(\w[-._\w]*\w@\w[-._\w]*\w\.\w{2,3})", fEmail)
    if regexEmail:
        # print "E-mail match"
        fEmailCheck = True
        eData["email"] = True
    else:
        # print "E-mail False"
        fEmailCheck = False
        eData["email"] = False

    fPhone = testForm["form_phone"].value
    fPhoneCheck = False
    regexPhone = re.search("^([0-9]( |-)?)?(\(?[0-9]{3}\)?|[0-9]{3})"
                           "( |-)?([0-9]{3}( |-)?[0-9]{4}|[a-zA-Z0-9]{7})$",
                           fPhone)
    if regexPhone:
        # print "Phone Match"
        fPhoneCheck = True
        eData["phone"] = True
    else:
        # print "Phone did not match"
        fPhoneCheck = False
        eData["phone"] = False
    if fNameCheck and fEmailCheck and fPhoneCheck:
        formIsValid = True
    else:
        formIsValid = False


if formIsValid:
    print "<p class='text-success' >Your form was submitted. Thank you </p>"
else:
    print "ran"
    # from model.view import View
    from controllers.Home import getErrors # this is not working wtf!! 
    e_model = Home()
    e_model.getErrors(eData)
