#!/usr/bin/python


class Home:
    def __init__(self):
        self.base_path = "/Users/Hugh/Sites/day2.python.com/controllers/"

    def get(self, myUrl, data={}):

        if "action" not in myUrl:
            action = "home"
        else:
            action = myUrl.getvalue("action")

        data = {
            "site_title": "MyPython Web Site",
            "logo_title": "My WebSite Logo",
            "body_text": "This is my main body text",
            "copyright_info": "fullsail university 2013"
        }  # end collection
        from model.view import View # WHY the errors?
        view_model = View()
        view_model.print_header()

        if action == "home":
            view_model.get_view("homePage/header", data)
            view_model.get_view("homePage/body", data)
            view_model.get_view("homePage/footer", data)

    def getErrors(selfself, eData):
        print "ran"
        from model.view import View
        view_model = View()
        view_model.print_header()
        view_model.get_view("homePage/header", eData)
        view_model.get_view("homePage/body", eData)
        view_model.get_view("homePage/footer", eData)