#!/usr/bin/python 

import cgi
import cgitb

myUrl = cgi.FieldStorage()

if "controller" not in myUrl:
    con = "home"
else:
    con = myUrl.getValue("controller")

if con == "home":
    from controllers.Home import Home

    Home().get(myUrl)
elif con == "utilities":
    from controllers.Utility import Utility
    Utility().get(myUrl)
