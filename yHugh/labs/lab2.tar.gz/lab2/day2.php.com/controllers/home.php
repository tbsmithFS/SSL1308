<?php		
	class Home {
		public static function setPath ($errorPath){
			if ($errorPath == null){
				require_once("models/view.php");
			}else {
				require_once($errorPath);// <---------------------- WHY WONT THIS WORK 
			}
		}
		function get ($pairs, $data ="", $eData= ""){
			$data = array (
				'site_title' => "My PHP", 
				'logo_title' => "My PHP logo", 
				'main_body_text' => "Main body text for PHP site", 
				'copyright_info' => "Full Sail University 2013",
			);
			if (empty($pairs["action"])){
				$action = "home";	
			} else {
				$action = $pairs["action"];
			} 
			
			$view_model = new View();
			$view_model->printHeader();
			$view_model->getView("homePage/header", $data);
			$view_model->getView("homePage/body", $data);
			$view_model->getView("homePage/footer", $data);
		}
	}
?>
