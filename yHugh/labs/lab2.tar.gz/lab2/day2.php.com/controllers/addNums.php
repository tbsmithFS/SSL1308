<?php

	$var1 = $_GET["number1"];
	$var2 = $_GET["number2"];
	$sum = $var1+$var2;

	echo "<h1>Your Numbers</h1>";
	echo "<p> $var1 </p>";
	echo "<p>$var2</p>";
	echo "<p>the Sum is $sum</p>"
	
?>