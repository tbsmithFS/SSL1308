<footer>
	<p><?php echo $data{"copyright_info"}?></p>
</footer>