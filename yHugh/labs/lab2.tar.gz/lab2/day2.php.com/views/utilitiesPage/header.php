<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../css/bootstrap.css" type="text/css" >
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"/>
    <title>Skully</title>
</head>
<head>
   <div class="navbar">
  <a class="navbar-brand" href="#"><?php echo $data{"site_title"} ?></a>
  <ul class="nav navbar-nav"> 
    <li class="active"><a href="#"><?php echo $data{"link1_info"}?></a></li>
    <li><a href="#"><?php echo $data{"link2_info"}?></a></li>
  
    <li><a href="#">Link</a></li>
  </ul>
</div>
</head>