<footer class="col-lg-2">
	<p><?php echo $data{"copyright_info"}?></p>
</footer>