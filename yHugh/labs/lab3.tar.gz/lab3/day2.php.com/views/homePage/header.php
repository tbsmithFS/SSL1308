<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../css/bootstrap.css" type="text/css" >
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"/>
    <title>Skully</title>
</head>
<head>
   <div class="navbar">
  <a class="navbar-brand" href="#"><?php echo $data{"site_title"} ?></a>
  <ul class="nav navbar-nav"> 
    <li class="active"><a href="#">Home</a></li>
    <li><a href="http://day2.php.com/utilities">UtilityPage</a></li>
    <li><a href="#">Link</a></li>
  </ul>
</div>
</head>