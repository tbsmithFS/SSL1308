<div class=".container max-width">
	<div class="hero-unit">
		<h1><?php echo $data{"logo_title"}?></h1>
		<p>
			<?php echo $data{"main_body_text"}?>
		</p>
	</div>
</div>
<div class="col-lg-2">
	<form action="controllers/addNums.php"
		  enctype="multipart/form-data"
		  method="get"
		  >
	  <fieldset>
	    <legend>Legend</legend>
		    <div class="form-group">
		    	<div class="form-group">
		    		<label for-"myName">Enter A Number </label>
		    		<input type="text" class="form-control"  placeholder="Enter Your Number" name="number1">
		    	</div>
		    	<div class="form-group">
		      <label for="example	InputEmail">Enter another Number</label>
		      <input type="text" class="form-control"  placeholder="Enter a Number" name="number2">
		    </div>
	    </div>
		    	<button type="submit" class="btn btn-default" name="submitButton">Submit</button>
	  </fieldset>
	</form>
</div>