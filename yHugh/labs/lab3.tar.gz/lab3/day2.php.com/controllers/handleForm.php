<?php
	$valueOne = "unchecked";
	$valueTwo = "unchecked";
	$selectedValue = $_GET["formVal"];
	// Radio Button Validation 
	if ($selectedValue == "valOne" || $selectedValue == "valTwo"){

		if($selectedValue == "valOne"){
			// echo "you chose value One";
			$valueOne = "Checked";	
		}
		if($selectedValue == "valTwo") {
			// echo "you chose value two";
			$valueTwo = "Checked";
		}
	}
	else {
		// echo "Both Values were unchecked";
		// validation error Here
	}
	
	$iExist = false;
	// Check box Validation 
	$checkVal = $_GET["form_check"];
	if ($checkVal == "checked"){
		$iExist = true;
	}
	$fName = $_GET["first_name"];
	$regName = '/^[a-zA-Z]+/';
	$nameCheck = false;
	// Name validation 
	if (preg_match($regName, $fName)){
		// echo "a match was found";
		$nameCheck = true;
	}else {
		// echo "invalid first name";
		// validation error here 
		$nameCheck = false;
	}
	
	$fEmail  = $_GET["form_email"]; 
	$emailCheck = false;
	$rEmail = '(\w[-._\w]*\w@\w[-._\w]*\w\.\w{2,3})';
	if(preg_match($rEmail, $fEmail)){
		$emailCheck = true;
	}else {
		$emailCheck = false;
	}
	
	$fPhone = $_GET["form_phone"];
	$rPhone = "/^([0-9]( |-)?)?(\(?[0-9]{3}\)?|[0-9]{3})( |-)?([0-9]{3}( |-)?[0-9]{4}|[a-zA-Z0-9]{7})$/";
	$phoneCheck = false;
	if(preg_match($rPhone, $fPhone)){
		$phoneCheck = true;
	}else {
		$phoneCheck = false;
	}

	if ($phoneCheck && $emailCheck && $nameCheck ){
		$formIsValid = true;
	}else {
		$formIsValid = false;
	}
	
	if ($formIsValid){
		// process form 
		echo "<h1>Your Form Information</h1>";
		echo "<p>Name: $fName</p></break>";
		echo "<p>Email: $fEmail</p></break>";
		echo "<p>Phone: $fPhone</p></break>";
		if ($valueOne == "Checked"){
			echo "<p>you prefer Value 1 over vaLue 2</p></break>";
		}
		if ($valueTwo == "Checked"){
			echo "<p>You prefer value 2 over value 1</p></break>";
		}
		if ($valueOne == "unchecked" && $valueTwo == "unchecked"){
			echo "<p>You did not select a value</p></break>";
		} 
		if ($iExist){
			echo "<p> You claim to Exist</p></break>";
		}
		if (!$iExist){
			echo "<p> You claim not to exist</p></braek>";
		}
		echo "</h3 class='text-success'> Congrats Your form processed successfully </h3>";
	}else {
		// echo "error plese fix form";
		include "home.php";
		$controller = new Home();
		$controller::setPath("../models/view.php"); 
		$controller->get($_GET, $errors);
	}
	
?>