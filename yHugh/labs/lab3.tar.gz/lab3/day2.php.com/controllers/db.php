<?php
	include ("models/DB.php");
	
	$test = new DBConnector();
	
?>