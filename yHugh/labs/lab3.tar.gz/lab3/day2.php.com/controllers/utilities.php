<?php
	require_once("models/view.php");
	class Util {
		function get ($pairs, $data=""){
			$data = array (
			"site_title" => "My Utilities Page",
			"logo_title" => "My PHP Logo", 
			"Main_body_text" => "this is the utilities page.",
			"copyright_info" => "Hugo Ybarra made this ",
			"link1_info"=> "Utilities",
			"link2_info"=> "Home",
			);
			if (empty($pairs["action"])){
				$action = "home";
			} else {
				$action = $pairs["action"];
			}
			$view_model = new View();
			$view_model->printHeader();
			$view_model->getView("utilitiesPage/header", $data);
			$view_model->getView("utilitiesPage/body", $data);
			$view_model->getView("utilitiesPage/footer", $data);
		}	
	}
?>