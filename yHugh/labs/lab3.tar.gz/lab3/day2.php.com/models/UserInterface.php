<?php
	class UserInterface {
		public static function printHeader(){
			echo "Content-type:text/html\n\n";
		}
		public function getView($file, $data){
			
		}
	}; // end User interface
?>