<?php	
	include ("controllers/db.php");
	
	if (empty($_GET["controller"])){
		$pageCon = "home";
	}else {
		$pageCon = $_GET["controller"];
	}
	
	if ($pageCon == "home"){
		include "controllers/home.php";
		
		$controller = new Home();
		$controller::setPath(null, null);
		$controller->get($_GET);
	}else if ($pageCon == "utilities"){
		include "controllers/utilities.php";
		$controller = new Util();
		
		$controller->get($_GET);
	}else if ($pageCon == "user"){
		include "controllers/user.php";
		// $controller = new User();
		// $controller->get($_GET);
	}

?>


	

	
	

	
	
