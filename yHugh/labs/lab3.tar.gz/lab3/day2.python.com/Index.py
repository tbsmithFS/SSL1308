#!/usr/bin/python 

import cgi
import cgitb
cgitb.enable()

myUrl = cgi.FieldStorage()

if "action" not in myUrl:
    con = "home"
else:
    con = myUrl.getvalue("action")

if con == "home":
    from controllers.Home import Home
    Home().get(myUrl)
elif con == "submitForm":
    from controllers.Home import Home
    Home().get(myUrl)
elif con == "utilities":
    from controllers.Utility import Utility
    Utility().get(myUrl)
