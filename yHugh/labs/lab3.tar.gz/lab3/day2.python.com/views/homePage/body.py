<div class="span8 hero-unit" id="myHero">
	<h1>Hey Look right here!</h1>
	<p>
		If I had something to say to you I would probably
		put it right here! That being said, if youre reading this
		that means that i had something to say ^_^
	</p>
	<p>
		<a class="btn btn-primary btn-large"> Learn more </a>
	</p>
</div>
<div class="col-lg-2">
	<form action="/home/submitForm"
		  enctype="multipart/form-data"
		  method="post"
		  >
	  <fieldset>
	    <legend>Legend</legend>
		    <div class="form-group">
		    	<div class="form-group">
		    		<label for-"myName">Name: </label>
		    		<input type="text" class="form-control" id="myName" placeholder="Your Name here" name="first_name">
		    	</div>
		    	<div class="form-group">
		      <label for="example	InputEmail">Email:</label>
		      <input type="email" class="form-control" id="exampleInputEmail" placeholder="Enter email" name="form_email">
		    </div>
		    <div class="form-group">
		      <label for="phone">PhoneNumber</label>
		      <input type="phone" class="form-control" id="phone" placeholder="( xxx ) xxx-xxxx" name="form_phone">
		    </div>
		    <div class="radio">
		    	<label for="val1">
		    		<input type="radio" id="val1" name="formVal" value="valOne">Val 1
		    	</label>
		    </div>
		    <div class="radio">
		   		<label for="val2">
		    		<input type="radio"  id="val2" name="formVal" value="valTwo">Val 2
		    	</label>
		    </div>
		     <div class="checkbox">
	      <label>
	        <input type="checkbox" name="form_check" value="checked"> Do you Exist?
	      </label>
	    </div>
		    	<button type="submit" class="btn btn-default" name="submitButton">Submit</button>
	  </fieldset>
	</form>
</div>