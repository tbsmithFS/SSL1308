<?php
//include("settings/db.php");
include("models/view.php");

$view = new View();

$view -> printHeader();

$data = array(
        "site_title" => "My PHP website title",
        "logo_title" => "My PHP Logo",
        "main_body_text" => "Main body text for PHP website",
        "copyright_info" => "Full Sail University 2013",
);

$view -> getView("header", $data);
$view -> getView("body", $data);
$view -> getView("footer", $data);


echo "test";

?>
