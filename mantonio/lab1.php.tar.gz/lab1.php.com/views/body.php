<div id="wrapper">
            <div id="content" class="wrap">
                <h1>Sign up it's FREE!</h1>
                <section id="signup_form">
                    <form id="signUpForm">
                        <p>
                            <label for="firstName">First Name:</label>
                            <input id="firstName" type="text" name="firstName" placeholder="John"/>
                        </p>

                        <p>
                            <label for="lastName">Last Name:</label>
                            <input id="lastName" type="text" name="lastName" placeholder="Smith"/>
                        </p>

                        <p>
                            <label for="email">Email:<span class="required">*</span></label>
                            <input id="email" type="email" name="email" placeholder="example@email.com"/>
                        </p>

                        <p>
                            <label for="userName">Username:<span class="required">*</span></label>
                            <input id="userName" type="text" name="userName" required="required" placeholder="jsmith"/>
                        </p>

                        <p>
                            <label for="password">Password:<span class="required">*</span></label>
                            <input id="password" type="password" name="password" required="required"
                                   placeholder="********"/>
                        </p>

                        <p>
                            <label for="confirm">Confirm Password:<span class="required">*</span></label>
                            <input id="confirm" type="password" name="confirm" required="required" placeholder="********"/>
                        </p>

                        <p>
                            <a class="register_btn" href="#">Sign up NOW!</a>
                        </p>
                    </form>
                </section>

                <section id="form_info">
                    <p>Please enter your information and
                        choose a username and password.</p>

                    <p>After signing up you will be taken to <span class="brand">ur<span>to</span>do</span> where you can
                        create your first project and add tasks.</p>

                    <p>*By signing up you have indicated that you have read and understand urtodo&quot;s <a href="#">Terms of
                        Service</a>.</p>
                </section>

                <aside>
                    <h2>Already a member?</h2>

                    <form id="loginForm">
                        <p>
                            <label for="memberName">Username:</label>
                            <input id="memberName" type="text" name="memberName" required="required" placeholder="jsmith"/>
                        </p>

                        <p>
                            <label for="memberPass">Password:</label>
                            <input id="memberPass" type="password" name="memberPass" required="required"
                                   placeholder="********"/>
                        </p>

                        <p>
                            <a href="#" class="login_btn">Login</a>
                        </p>
                    </form>
                </aside>
                <div id="clearfooter"></div>
            </div>
        </div>

        