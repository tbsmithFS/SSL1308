<?php

class Home {
  function get($pairs) {
    if(empty($pairs["action"])) {
      $action = "showHomePage";
    }else {
      $action = $pairs["action"];
    }

    if($action == "showHomePage") {

      //Assemble views, data
      echo "Showing Home Page...home controller page working";
      //show output to user

    }else {
      echo "Not showing the Home page (action was " . $pairs["action"] . ")";
    }
  }
}

?>