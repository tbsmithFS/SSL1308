<?php

//include("settings/db.php");
include("models/view.php");
include("controller/Home.php");

require_once "controller/Home.php";

$view = new View();

$view -> printHeader();

$data = array(
  "site_title" => "My PHP website title",
  "logo_title" => "My PHP Logo",
  "main_body_text" => "Main body text for PHP website",
  "copyright_info" => "Full Sail University 2013",
);


/*
 * Get Views
 */
$view -> getView("header", $data);
$view -> getView("body", $data);
$view -> getView("footer", $data);

/*
 * Get the Controller
 */
if(empty($_GET["controller"])) {
  $con = "home";
}else {
  $con = $_GET["controller"];
}

"controller is ". $con; 

if($con == "home") {
  $homeInstance = new Home();
  $homeInstance -> get($_GET);
}else {
  echo "The controller was not home";
}

?>