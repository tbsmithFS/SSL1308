<html lang="en">
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

        <title>urtodo Task Management Application</title>
        <meta name="description" content="">
        <meta name="author" content="">

        <!--  Mobile viewport optimized: j.mp/bplateviewport -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- CSS concatenated and minified via ant build script-->
        <link href='http://fonts.googleapis.com/css?family=Geo' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Lato:100,300,400' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" type="text/css" href="/css/main.css">
        <link rel="stylesheet" type="text/css" href="css/fullcalendar.css">
        <!-- end CSS-->

    </head>

    <body>
       <div id="toolbar_bg">
            <div class="wrap logInOut">
                <p>Already a member? <span id="uname"></span><a id="login_link" class="goToSignup" href="#">Login</a></p>
            </div>
        </div> <!-- End #toolbar_bg -->

        <div id="header_bg">
            <header class="wrap">

                <!-- Logo -->
                <a href="index.html"><img id="logo" src="images/logo.png" title="urtodo Task Management Application"
                                          alt="urtodo Logo" /></a> <!-- End Logo -->

                <nav>
                    <ul>
                        <li><a class="goToSignup" href="#">Sign Up</a></li>
                        <li><a class="goToFeatures" href="#">Features</a></li>
                        <li><a href="#">About</a></li>
                    </ul>
                </nav>
            </header>
        </div> <!-- End #header_bg -->