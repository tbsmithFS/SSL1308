<div class="wrap cta">
    
    <ul id="cta_imgs">
        <li><img src="images/dashboard.jpg" alt="urtodo Dashboard View" /></li>
        <li><img src="images/project_view.jpg" alt="urtodoProject View" /></li>
        <li><img src="images/task_view.jpg" alt="urtodo Task View" /></li>
        <li><img src="images/signup.jpg" alt="urtodo Signup Page"></li>
    </ul>

    <div id="cta_txt">
        <p><span class="brand">ur<span>to</span>do</span> is a simple task management application that will help you manage your daily tasks or manage your team’s tasks.</p>
        <p>As a simple task manager, <span class="brand">ur<span>to</span>do</span> can help you stay on track to
        complete your daily tasks at hand. Simply create a new task, give it a description if you wish,
        and schedule a time for it to be completed.<a id="cta_btn" class="goToSignup" href="#" title="It's FREE!!!">Sign up NOW!</a></p>
    </div> <!-- End #cta_txt -->
</div>