	<div id="footer_bg">
		<footer class="wrap">
	   		<ul id="bottom_nav">
	        	<li><a class="goToSignup" href="#">Sign Up</a></li>
	            <li><a class="goToFeatures" href="#">Features</a></li>
	            <li><a href="#">About</a></li>
	            <li><a href="#">Contact</a></li>
	        </ul>
	        <p>Copyright &copy; 2013 urtodo, LLC</p>
	   	</footer>
	</div> <!-- End #footer_bg -->
</body>
</html>